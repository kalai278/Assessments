#!/usr/bin/env python
# coding: utf-8

# In[2]:


import requests


# In[3]:


from bs4 import BeautifulSoup

url = "https://en.wikipedia.org/wiki/List_of_prime_ministers_of_India"

a = requests.get(url).text

soup = BeautifulSoup(a,"html.parser")

r = soup.select('span [class="fn"]')

for i in r:
    print(i.text)


# In[4]:


import requests
data=requests.get("https://api.covidtracking.com/v1/us/daily.json").text
data


# In[5]:


import json
data1=json.loads(data)
data1


# In[6]:


a=[]
for i in data1:
    a.append([i["date"],i["states"],i["positive"], i["negative"],i["pending"],i["hospitalizedCurrently"],i["hospitalizedCumulative"],i["onVentilatorCurrently"],i["onVentilatorCumulative"],i["dateChecked"],i["death"],i["hospitalized"],i["totalTestResults"],i["lastModified"],i["recovered"],i["total"],i["posNeg"],i["deathIncrease"],i["hospitalizedIncrease"],i["negativeIncrease"],i["positiveIncrease"],i["totalTestResultsIncrease"],i["hash"]])
a    


# In[7]:


import pandas as pd
df=pd.DataFrame(data=a,columns=["date","states","positive","negative","pending","hospitalizedCurrently","hospitalizedCumulative","onVentilatorCurrently","onVentilatorCumulative","dateChecked","death","hospitalized","totalTestResults","lastModified","recovered","total","posNeg","deathIncrease","hospitalizedIncrease","negativeIncrease","positiveIncrease","totalTestResultsIncrease","hash"])
df


# In[8]:



from sqlalchemy import create_engine
create=create_engine("mysql+pymysql://root:kalai278@localhost/Sample")


# In[9]:


df.to_csv("Covid_info.csv")


# In[10]:


df1=pd.read_csv("Covid_info.csv")
df1.to_sql("Covidtest",create,if_exists="replace",index=False)


# In[ ]:





# In[17]:


import requests
from bs4 import BeautifulSoup
import pandas as pd


# In[18]:


url="https://en.wikipedia.org/wiki/List_of_prime_ministers_of_India"


# In[21]:


one=requests.get(url).text


# In[24]:


soup = BeautifulSoup(one,'html.parser')
indiatable=soup.find('table',('class','wikitable'))


# In[27]:


df=pd.read_html(str(indiatable))
df=pd.DataFrame(df[0])
df.columns=["no","no.1","portrait","name","party","tookoffice","leftoffice","time in office","lok sabha[e]","ministry","appointed by","not needed"]


# In[64]:


df["tookoffice"].mask(df["tookoffice"] =="19 March 1998[§]","19 March 1998",inplace = True)


# In[65]:


df[["name","party","tookoffice","leftoffice"]]


# In[66]:


df1=df.drop(26)


# In[67]:


df1["leftoffice"]=pd.to_datetime(df1['leftoffice'],infer_datetime_format=True)
df1['tookoffice']=pd.to_datetime(df1['tookoffice'],infer_datetime_format=True)


# In[68]:


df2=df1[['name','party','leftoffice','tookoffice']]
df2


# In[71]:


import pymysql
from sqlalchemy import create_engine
create=create_engine("mysql+pymysql://root:kalai278@localhost/Sample")


# In[72]:


df2.to_sql('indianprimeministers',create,if_exists='replace',index=False)


# In[ ]:




